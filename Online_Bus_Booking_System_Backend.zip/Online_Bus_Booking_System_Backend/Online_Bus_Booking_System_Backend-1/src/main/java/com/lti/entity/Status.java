package com.lti.entity;

public enum Status {

	BOOKED,CANCELLED
	
}
